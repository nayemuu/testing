import { productModel } from "@/models/productModel";
import connectMongo from "./mongo";
import { subCategoryModel } from "@/models/subCategoryModel";
import { colorModel } from "@/models/colorModel";
import { replaceMongoIdInArray } from "@/utils/mongoDB-utils";


export const getProducts = async (limit, offset) => {
    try {
        
        await connectMongo();
        const products = await productModel.find({}).populate("category", "name").populate("subCategory", "name").populate("colors", "name").lean();

        if (products.length === 0) {
            return { count: 0, limit: limit ? limit : 10, offset: offset ? offset : 0, products: [] };
          }

          const start = offset ? offset: 0;
          const end = (limit && offset) ? offset + limit: 10;

          const paginatedProducts = products.slice(start, end);


        return ({ count: products.length, limit: limit ? limit : 10, offset: offset ? offset : 0, products: replaceMongoIdInArray(paginatedProducts)});
    } catch (err) {
        console.log("error = ", err);
    }
};