import connectMongo from './mongo';
import { replaceMongoIdInArray } from '@/utils/mongoDB-utils';
import { replaceCloudinaryObjectIntoUrlInArray } from '@/utils/cloudinary-utils';
import { categoryModel } from '@/models/categoryModel';

async function getCategories() {
    await connectMongo();
    const dataFromMongodb = await categoryModel.find({}).select(['name', 'thumbnail', "logo"]).lean();

    let cloudinaryFields = ['thumbnail', 'logo']; 
    // console.log("dataFromMongodb = ", dataFromMongodb);
    let finalData = replaceCloudinaryObjectIntoUrlInArray(replaceMongoIdInArray(dataFromMongodb), cloudinaryFields);
    // console.log("finalData = ", finalData);
    return finalData;
}


export {
    getCategories
  };
  