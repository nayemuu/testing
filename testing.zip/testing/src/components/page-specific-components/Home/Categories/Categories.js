import React from 'react';
import CategoriesItem from './CategoriesItem';
import { getCategories } from '@/queries/category-queries';

async function Categories(props) {
  const categories = await getCategories();

  return (
    <div className="container py-16">
      <h2 className="text-2xl font-medium text-gray-800 uppercase mb-6">
        shop by category
      </h2>
      <div className="grid grid-cols-3 gap-3">
        {categories.map((singleCategory, index) => (
          <CategoriesItem index={index} singleCategory={singleCategory} />
        ))}
      </div>
    </div>
  );
}

export default Categories;
