import Image from 'next/image';
import React from 'react';

function CategoriesItem({ singleCategory }) {
  // console.log('singleCategory = ', singleCategory);
  return (
    <div className="relative rounded-sm overflow-hidden group aspect-[320/200] w-full">
      <Image
        src={singleCategory.thumbnail}
        alt={singleCategory.name}
        className="w-full object-cover"
        fill
      />
      <a
        href="#"
        className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center text-xl text-white font-roboto font-medium group-hover:bg-opacity-60 transition"
      >
        {singleCategory.name}
      </a>
    </div>
  );
}

export default CategoriesItem;
