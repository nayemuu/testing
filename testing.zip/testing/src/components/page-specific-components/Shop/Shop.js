'use client';

import { errorToastMessage } from '@/utils/toastifyUtils';
import axios from 'axios';
import { useEffect, useState } from 'react';
import ProductsGallery from './ProductsGallery/ProductsGallery';
import Sidebar from './Sidebar/Sidebar';

const Shop = () => {
  const [products, setProducts] = useState([]);
  console.log('products = ', products);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(
        `${process.env.NEXT_PUBLIC_BASE_URL}/api/product/`
      );

      console.log('response = ', response.data);
      if (response?.data?.products) {
        setProducts((previousProducts) => [
          ...previousProducts,
          ...response.data.products,
        ]);
      }
    } catch (error) {
      // console.log('error = ', error);
      if (error?.response?.data?.error) {
        errorToastMessage(error.response.data.error); //custom error message
        console.log('error.response.data.error = ', error.response.data.error);
      } else if (error?.message) {
        errorToastMessage(error.message);
      } else {
        errorToastMessage('SomeThing Went Wrong');
      }
    }
  };
  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <div className="container grid md:grid-cols-4 grid-cols-2 gap-6 pt-4 pb-16 items-start">
      <Sidebar />
      <ProductsGallery products={products} />
    </div>
  );
};

export default Shop;
