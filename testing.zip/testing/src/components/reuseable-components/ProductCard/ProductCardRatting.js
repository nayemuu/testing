'use client';
import { Rating } from 'react-simple-star-rating';

const ProductCardRatting = () => {
  return (
    <div className="flex">
      <Rating
        SVGstyle={{ display: 'inline' }}
        style={{ width: 'fit-content' }}
        transition
        initialValue={4.5}
        readonly={true}
        fillColor="#FFA800"
        allowFraction
        size={20}
      />
    </div>
  );
};

export default ProductCardRatting;
