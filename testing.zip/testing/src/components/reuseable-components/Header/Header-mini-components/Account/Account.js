import { FaRegUser } from 'react-icons/fa';

function Account({ dict }) {
  return (
    <div className="text-center text-gray-700 hover:text-primary transition relative">
      <div className="text-2xl flex justify-center">
        <span className="relative">
          <FaRegUser />
        </span>
      </div>
      <div className="text-xs leading-3">{dict.Header.account}</div>
    </div>
  );
}

export default Account;
