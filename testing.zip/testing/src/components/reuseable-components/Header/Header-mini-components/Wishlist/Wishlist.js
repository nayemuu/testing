import { FaRegHeart } from 'react-icons/fa';

function Wishlist({ dict }) {
  return (
    <div className="text-center text-gray-700 hover:text-primary transition relative">
      <div className="text-2xl flex justify-center">
        <span className="relative">
          <FaRegHeart />
          <div className="absolute right-[-10px] top-[-8px] min-w-5 min-h-5 aspect-square rounded-full flex items-center justify-center bg-primary text-white text-xs">
            8
          </div>
        </span>
      </div>
      <div className="text-xs leading-3">{dict.Header.wishlist}</div>
    </div>
  );
}

export default Wishlist;
