import React from 'react';
import { FaMagnifyingGlass } from 'react-icons/fa6';

function Searchbar() {
  return (
    <div className="h-full w-full max-w-xl relative hidden md:flex">
      <div className="absolute left-4 h-full flex justify-center items-center text-lg text-gray-400">
        <FaMagnifyingGlass />
      </div>
      <input
        type="text"
        name="search"
        id="search"
        className="w-full border border-primary border-r-0 pl-12 py-3 pr-3 rounded-l-md focus:outline-none hidden md:flex"
        placeholder="search"
      />
      <button className="bg-primary border border-primary text-white px-8 rounded-r-md hover:bg-transparent hover:text-primary transition hidden md:flex justify-center items-center">
        Search
      </button>
    </div>
  );
}

export default Searchbar;
