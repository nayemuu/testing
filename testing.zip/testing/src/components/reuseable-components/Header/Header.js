import Image from 'next/image';
import logo from '../../../assets/logo.svg';
import SearchBar from './Header-mini-components/SearchBar/SearchBar';
import Wishlist from './Header-mini-components/Wishlist/Wishlist';
import Cart from './Header-mini-components/Cart/Cart';
import Account from './Header-mini-components/Account/Account';
import { getDictionary } from '@/app/[lang]/dictionaries/dictionaries';
import Link from 'next/link';

async function Header({ lang }) {
  const dict = await getDictionary(lang);

  return (
    <header className="py-4 shadow-sm bg-white">
      <div className="container flex items-center justify-between">
        <Link href="/">
          <Image src={logo} alt="Logo" className="w-32" />
        </Link>

        <SearchBar />

        <div className="flex items-center space-x-4">
          <Wishlist dict={dict} />
          <Cart dict={dict} />
          <Account dict={dict} />
        </div>
      </div>
    </header>
  );
}

export default Header;
