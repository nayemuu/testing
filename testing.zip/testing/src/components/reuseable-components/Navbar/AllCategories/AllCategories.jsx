import React from 'react';
import bed from '../../../../assets/components/reuseable-components/Navbar/icons/bed.svg';
import sofa from '../../../../assets/components/reuseable-components/Navbar/icons/sofa.svg';
import office from '../../../../assets/components/reuseable-components/Navbar/icons/office.svg';
import terrace from '../../../../assets/components/reuseable-components/Navbar/icons/terrace.svg';
import bed2 from '../../../../assets/components/reuseable-components/Navbar/icons/bed-2.svg';
import restaurant from '../../../../assets/components/reuseable-components/Navbar/icons/restaurant.svg';
import AllCategoriesItem from './AllCategoriesItem';
import { FaBars } from 'react-icons/fa';
import { getCategories } from '@/queries/category-queries';

async function AllCategories({ dict }) {
  const categories = await getCategories();
  // console.log('categories = ', categories);

  return (
    <div className="px-8 py-4 bg-primary md:flex items-center cursor-pointer relative group">
      <span className="text-white">
        <FaBars />
      </span>
      <span className="capitalize ml-2 text-white">
        {dict.Navbar.AllCategories}
      </span>

      <div
        className="absolute left-0 top-full bg-white shadow-md py-3 divide-y divide-gray-300 divide-dashed opacity-0 group-hover:opacity-100 transition duration-300 invisible group-hover:visible w-full"
        // style="width: 300px;"
      >
        {categories.map((singleCategory) => (
          <AllCategoriesItem
            singleCategory={singleCategory}
            key={singleCategory.id}
          />
        ))}
      </div>
    </div>
  );
}

export default AllCategories;
