import Image from 'next/image';
import React from 'react';

function AllCategoriesItem({ singleCategory }) {
  const { name, logo} = singleCategory;
  return (
    <a
      href="#"
      className="flex items-center px-6 py-3 hover:bg-gray-100 transition"
    >
      <Image
        src={logo}
        alt={name}
        className="w-5 h-5 object-contain"
        height={20}
        width={20}
      />
      <span className="ml-6 text-gray-600 text-sm">{name}</span>
    </a>
  );
}

export default AllCategoriesItem;
