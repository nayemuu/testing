import mongoose, { Schema } from 'mongoose';

const colorSchema = new Schema({
  name: {
    type: String,
    trim: true,
    required: true,
    maxLength: 50,
    unique: true,
  },
  slug: {
    type: String,
    unique: true,
    lowercase: true,
  },
  colorCode: {
    type: String,
    unique: true,
  },
});

export const colorModel =
  mongoose.models.Color ?? mongoose.model('Color', colorSchema);
