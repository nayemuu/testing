import mongoose, { Schema, Types } from 'mongoose';

const productSchema = new Schema({
    name: {
        type: String,
        trim: true,
        required: true,
    },
    thumbnail: {
        type: String,
        trim: true,
        required: true,
    },
    images: {
        type: [String], // Corrected to specify an array of strings
        required: true,
    },
    stock: {
        type: Number,
        required: true,
    },
    brand: {
        type: String,
        trim: true,
        required: true,
    },
    category: {
        type: Object,
        ref: "Category",
        required: true
    },
    subCategory: {
        type: Object,
        ref: "SubCategory",
        required: true,
    },
    sku: {
        type: String,
        trim: true,
        required: true,
    },
    price: {
        type: Number,
        required: true,
    },
    discountPercentage : {
        type: Number,
        required: true,
    },
    colors: [{
        type: Object,
        ref: "Color",
        required: false
    }],
    description:{
        type: String,
        trim: true,
        required: true,
    },
    reviews:{
        type: Object,
        required: true,
    }, 
    rating: {
        type: Number,
        required: true,
        default:3.5
    },   
    keywords: {
        type: [String], // Corrected to specify an array of strings
    },  
    sizes: {
        type: [String], // Corrected to specify an array of strings
    },
    totalSold: {
        type: Number,
        required: true,
        default:0
    },
});


  export const productModel =
  mongoose.models.Product ?? mongoose.model('Product', productSchema);

