import mongoose, { Schema } from 'mongoose';

const schema = new Schema({
  name: {
    type: String,
    trim: true,
    required: true,
    maxLength: 50,
    unique: true,
  },
  slug: {
    type: String,
    unique: true,
    lowercase: true,
  },
  thumbnail: {
    type: Object,
    required: true,
  },
  logo: {
    type: Object,
    required: true,
  },
});

export const categoryModel =
  mongoose.models.Category ?? mongoose.model('Category', schema);
