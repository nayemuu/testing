import { getProducts } from '@/queries/queries';

export async function GET(_request, { params }) {
  const limit = params?.limit ? params.limit : 0;
  const offset = params?.offset ? params.offset : 0;
  const result  = await getProducts(limit, offset);
  
  console.log("result = ", result);
  return Response.json(result);
}

