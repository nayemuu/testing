import Banner from '@/components/page-specific-components/Home/Banner/Banner';
import Categories from '@/components/page-specific-components/Home/Categories/Categories';
import Features from '@/components/page-specific-components/Home/Features/Features';
import Copyright from '@/components/reuseable-components/Copyright/Copyright';
import Footer from '@/components/reuseable-components/Footer/Footer';
import React from 'react';

function homePage({ params: { lang } }) {
  return (
    <>
      <Banner />
      <Features />
      <Categories />
    </>
  );
}

export default homePage;
