import Shop from '@/components/page-specific-components/Shop/Shop';
import Breadcrumb from '@/components/reuseable-components/Breadcrumb/Breadcrumb';
import React from 'react';

const page = () => {
  return (
    <>
      <Breadcrumb>Shop</Breadcrumb>
      <Shop/>
    </>
  );
};

export default page;
