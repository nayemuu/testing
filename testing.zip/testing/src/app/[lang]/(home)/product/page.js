import ProductDescription from '@/components/page-specific-components/Product/ProductDescription/ProductDescription';
import ProductDetails from '@/components/page-specific-components/Product/ProductDetails/ProductDetails';
import RelatedProducts from '@/components/page-specific-components/Product/RelatedProducts/RelatedProducts';
import Breadcrumb from '@/components/reuseable-components/Breadcrumb/Breadcrumb';
import React from 'react';

const page = () => {
  return (
    <>
      <Breadcrumb>Product</Breadcrumb>
      <ProductDetails />
      <ProductDescription />
      <RelatedProducts />
    </>
  );
};

export default page;
