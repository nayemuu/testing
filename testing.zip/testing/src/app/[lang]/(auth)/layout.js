import Copyright from '@/components/reuseable-components/Copyright/Copyright';
import Footer from '@/components/reuseable-components/Footer/Footer';
import Header from '@/components/reuseable-components/Header/Header';
import Navbar from '@/components/reuseable-components/Navbar/Navbar';

export default function RootLayout({ children, params: { lang } }) {
  return (
    <div>
      <Header lang={lang} />
      <Navbar lang={lang} />
      {children}
      <Footer />
      <Copyright />
    </div>
  );
}
